from turtle import Turtle, Screen
import random

# Instances
turt_1 = Turtle()
turt_2 = Turtle()
turt_3 = Turtle()
turt_4 = Turtle()
screen = Screen()

# Lists
list_turtle = [turt_1, turt_2, turt_3, turt_4]
list_colors = ["purple", "green", "blue", "black"]

# Driver
screen.setup(width = 500, height = 400)
user_bet = screen.textinput(title = "Bet", prompt = "Which turtle would you like to bet on? Pick a color: ")

# Color States
i = 0
for color in list_colors:
    list_turtle[i].color(color)
    i+=1

# Shapes State
for turtle in list_turtle:
    turtle.shape("turtle")

# Send Turtles to starting line
y_cord = -100
for turtle in list_turtle:
    turtle.penup()
    turtle.goto(x = -240, y = y_cord)
    turtle.pendown()
    y_cord += 50

# Pass in a turtle, set param_turtle == to that arg and move it forward
# param_turtle will be the same instance of the passed in obj of the Turtle Class
def move_forward(param_turtle):
    param_turtle.forward(random.randint(0, 10))

# While the race is not finished, move the turtle forward. If that turle has reached the finish line after moving
# stop the race and output the corresponding txt

# else call the move_forward func, pass in the turtle you want to move forward, and move it forward by a random amnt
race_finish = False
while race_finish == False:

    for turtle in list_turtle:

        move_forward(turtle)

        if turtle.xcor() > 230:
            race_finish = True
            winning_turtle = turtle.pencolor()

            if user_bet == winning_turtle:
                print("Congrats! You won the bet!")
            else:
                print(f"Sorry {winning_turtle} won. You lost the bet.")





screen.exitonclick()